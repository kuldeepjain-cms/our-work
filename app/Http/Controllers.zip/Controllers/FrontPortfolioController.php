<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use Illuminate\Http\Request;
use Hash;
use URL;
class FrontPortfolioController extends Controller
{
    
	public function index()
    {
		
        return view('portfolio_check'); 
            
    }

    public function show($token)
    {

        $token_new = DB::table('accesstoken')->where('accesstoken', $token)->first();
        $categories = DB::select('select * from category');
        if($token_new->status == 1){
            if($token_new->technology == 'all'){
                $portfolio = DB::select('select * from portfolio');
            }else{
                 $portfolio = DB::table('accesstoken')
            ->leftJoin('portfolio', 'accesstoken.technology', '=', 'portfolio.technology')
            ->where('accesstoken.accesstoken',$token)
            ->where('accesstoken.status',1)
            ->get();
            }


             if(!empty($portfolio)){
                return view('portfolio', ['portfolios' => $portfolio,'technology' => $token_new->technology, 'categories' => $categories]);//
            }else{

                return view('error');
            }

        }else{
            return view('portfolio_check');
        }


    }

    public function singledetails($token)
    {   
        $portfolio = DB::select('select * from portfolio where portfolioid = '.$token);
        return view('details_page', ['portfolio' => $portfolio]);
    }

    public function newTheme($token=null) {
        if(!empty($token)){
            $data = array();
            $data['technologies'] = DB::select('select technology_id, technology_name from technology where parent_id = 0');
            $data['categories'] = DB::select('select category_id, category_name from category where parent_id = 0');
            $data['tags'] = DB::select('select tag_id, tag_name from tag');
            $data['themes'] = DB::select('select theme_id, theme_name from theme');
            $data['packages'] = DB::select('select package_id, package_name from package');
            $token_new = DB::table('accesstoken')->where('accesstoken', $token)->first();

            if($token_new->status == 1){
                if($token_new->technology == 'all'){
                    $portfolio = DB::select('select * from portfolio ORDER BY portfolioid DESC LIMIT 12');
                }else{
                     $portfolio = DB::table('accesstoken')
                    ->leftJoin('portfolio', 'accesstoken.technology', '=', 'portfolio.technology')
                    ->where('accesstoken.accesstoken',$token)
                    ->where('accesstoken.status',1)
                    ->get();
                }
                $data['portfolios'] = $portfolio;
               
                return view('new_theme')->with($data);
            } else {
                return view('portfolio_check');
            }
        } else {
            return view('portfolio_check');
        }
        
    }

    public function ajaxloadmore() {
        $portfolio_count = DB::select('select count(*) as num_rows from portfolio ORDER BY portfolioid DESC');
       
        $allNumRows = $portfolio_count[0]->num_rows;
        $showLimit = 12;
        $portfolio = DB::select("select * from portfolio WHERE portfolioid < ".$_POST['id']." ORDER BY portfolioid DESC LIMIT $showLimit");
        $html = '';
        foreach ($portfolio as $portfolio) {
            $postID = $portfolio->portfolioid;
            $html .= " <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 gallery'>
            <div class='hover ehover10'>
                <img class='img-responsive' src=". URL::asset('template/frontend/images/'.$portfolio->image) ." alt='Title img' />
                <div class='point'>
                    <p>
                        <a data-fancybox='images' href=". URL::asset('template/frontend/images/'.$portfolio->image) ." data-caption='Hitt'>
                            <i class='zoom'></i>
                        </a>
                    </p>
                </div>
                <div class='overlay' style='background: #74bd30;'>
                    <div class='col-lg-8 col-md-12 col-sm-12 col-xs-12'>
                    <h2>".$portfolio->title."</h2>
                    <h3>Categories: -</h3>
                    <ul class='technology'>
                        <li>
                            <a href='javascript:void(0);'>
                                Wordpress
                            </a>
                        </li>        
                    </ul>
                    </div>
                     <a target='_blank' href=".url('portfoliodetail/'.$portfolio->portfolioid )." class='info'>VIEW MORE</a>
                </div>
            </div>
        </div>";
        
        }
        if($allNumRows > $showLimit){
            $html .= "<div id='overlay' class='load-more' lastID='".$postID."' style='display: none;'><i class='fa fa-spinner fa-spin spin-big'></i></div>";
        } else {
            $html .= "<div id='overlay' class='load-more' lastID='0'><i class='fa fa-spinner fa-spin spin-big'></i></div>";
        }
        
        return $html;
    }

    public function filterData(Request $request) {

        //return $request->input('technology');
        //return $request->input('category');
        //return $request->input('tag');
        //return $request->input('multitheme');
        //return $request->input('multisite');
        //return $request->input('theme');
        //return $request->input('package');
        $where="";
        $technology = $request->input('technology');
        $category = $request->input('category'); 
        $tag = $request->input('tag');
        $theme = $request->input('theme');
        $package = $request->input('package');
        $multitheme = $request->input('multitheme');
        $multisite = $request->input('multisite');

       

        if($technology !="" && $technology!='undefined'){

            $where .= ' technology='. $technology;
        }

        if(isset($category) && $category!=""){
            if(!empty($where)) {
                 $where .= ' and ';
            }
            $where .= ' category IN('. $category.')';
        }
       
        if(isset($tag) && $tag!=""){
            if(!empty($where)) {
                 $where .= ' and ';
            }

            $where .= ' tags IN('. $tag.')';
        }
        if(isset($theme) && $theme!=" "){
            if(!empty($where)) {
                 $where .= ' and ';
            }

            $where .= ' theme IN('. $theme.')';
        }
        if(isset($package) && $package!=" "){
            if(!empty($where)) {
                 $where .= ' and ';
            }
            $where .= ' js_css_packages IN('. $package.')';
        }
        if(isset($multitheme) && $multitheme!=" "){
            if(!empty($where)) {
                 $where .= ' and ';
            }
            
            $where .= ' multi_theme='. $multitheme;
        }
        if(isset($multisite) &&  $multisite!=" "){
            if(!empty($where)) {
                 $where .= ' and ';
            }
            
            $where .= ' multi_sites='. $multisite;
        }


   
        //return "select * from portfolio WHERE".$where." ORDER BY portfolioid DESC";

        $portfolio = DB::select("select * from portfolio WHERE ".$where." ORDER BY portfolioid DESC");
        $html = '';
        foreach ($portfolio as $portfolio) {
            $postID = $portfolio->portfolioid;
            $html .= " <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 gallery'>
            <div class='hover ehover10'>
                <img class='img-responsive' src=". URL::asset('template/frontend/images/'.$portfolio->image) ." alt='Title img' />
                <div class='point'>
                    <p>
                        <a data-fancybox='images' href=". URL::asset('template/frontend/images/'.$portfolio->image) ." data-caption='Hitt'>
                            <i class='zoom'></i>
                        </a>
                    </p>
                </div>
                <div class='overlay' style='background: #74bd30;'>
                    <div class='col-lg-8 col-md-12 col-sm-12 col-xs-12'>
                    <h2>".$portfolio->title."</h2>
                    <h3>Categories: -</h3>
                    <ul class='technology'>
                        <li>
                            <a href='javascript:void(0);'>
                                Wordpress
                            </a>
                        </li>        
                    </ul>
                    </div>
                     <a target='_blank' href=".url('portfoliodetail/'.$portfolio->portfolioid )." class='info'>VIEW MORE</a>
                </div>
            </div>
        </div>";
        
        }
        if(!empty($html)) {
            return $html;
        } else {
            return "<br/><br/><center><strong>No Portfolio found</strong></center>";
        }
        
    }
}
