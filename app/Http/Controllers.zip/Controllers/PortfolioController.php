<?php

namespace App\Http\Controllers;

use App\Portfolio;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use Session;
class PortfolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth:admin');
    } 
    public function index()
    {
        $data = array();
        $data['page'] = 'portfolio';
        $data['portfolios'] = DB::select('select * from portfolio order by portfolioid desc');
        return view('admin/portfolio/portfolio',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        if ($request->isMethod('post')) {

            $title = $request->input('name'); 
            $technology = $request->input('technology'); 
            $content =  addslashes($request->input('content')); 
            $site_link =  $request->input('site_link');
            $display_index = $request->input('display_index');

            $web_server = $request->input('web_server');
            $theme = $request->input('theme');
            $multi_theme = $request->input('multi_theme');
            $multi_site = $request->input('multi_site');
            $duration = $request->input('duration');
            $addons = $request->input('addons');

            
            
            $this->validate($request,[
                'name' => 'required',
                'technology' => 'required',
                'display_index' => 'required|unique:portfolio',
                'content' => 'required',
                'site_link' => 'required',
                'tags'  => 'required',
                'duration' => 'required'

            ]);

            $filename = '';
            if($request->input('category')){
                $category = implode(",", $request->input('category'));
            }else{
                $category = " ";
            }
            if($request->input('tags')){
                $tags =  implode(",", $request->input('tags'));
            }else{
                $tags = " ";
            }
            if($request->input('js_css_package')){
                $js_css_package = implode(",", $request->input('js_css_package'));
            }else{
                $js_css_package = " ";
            }
            if($request->input('payment_method')){
                $payment_method = implode(",", $request->input('payment_method'));
            }else{
                $payment_method = " ";
            }

            if($request->file('image') != ''){
                $file = $request->file('image')->getClientOriginalName(); 
                $extension = explode(".", $file);
                $filename = date('ymdhis').".".$extension[1];
                $request->file('image')->move('template/frontend/images/', $filename);
            } 
            $id = DB::table('portfolio')->insertGetId(
                        ['title' => $title,'category' => $category,'technology' => $technology,'content' => $content,'site_link'=>$site_link,'image'=>$filename,'tags'=>$tags,'display_index'=>$display_index, 'web_server' => $web_server, 'theme' => $theme, 'js_css_packages' => $js_css_package, 'payment_methods' => $payment_method, 'multi_theme' => $multi_theme, 'multi_sites' => $multi_site, 'duration' => $duration, 'addons' => $addons]);

           
            if($id != ''){
                Session::flash('message', 'Portfolio added successfully.');
                return redirect('admin/portfolio')->withInput();
            }
            Session::flash('message', 'Portfolio added successfully.');
            return redirect('admin/portfolio')->withInput();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Portfolio  $portfolio
     * @return \Illuminate\Http\Response
     */
    public function show(Portfolio $portfolio)
    {
        $data = array();
        $data['page'] = 'portfolio';
        $data['categories'] = DB::select('select * from category');
        $data['technologies'] = DB::select('select * from technology');
        $data['servers'] = DB::select('select * from server');
        $data['themes'] = DB::select('select * from theme');
        $data['packages'] = DB::select('select * from package');
        $data['payments'] = DB::select('select * from payment');
        $data['tag'] = DB::select('select * from tag');
        $data['displayindex'] = DB::select('select * from portfolio order by display_index DESC LIMIT 1');
        return view('admin/portfolio/add',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Portfolio  $portfolio
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = array();
    
        $data['results'] = DB::select('select * from portfolio where portfolioid = '.$id);
        $data['categories'] = DB::select('select * from category');
        $data['technologies'] = DB::select('select * from technology');
        $data['servers'] = DB::select('select * from server');
        $data['themes'] = DB::select('select * from theme');
        $data['packages'] = DB::select('select * from package');
        $data['payments'] = DB::select('select * from payment');
        $data['tag'] = DB::select('select * from tag');
        $data['page'] = 'portfolio';
        return view('admin/portfolio/edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Portfolio  $portfolio
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Portfolio $portfolio)
    {
        if ($request->isMethod('post')) {

            $date = date('Y-m-d');
            $title = $request->input('name'); 
            $technology = $request->input('technology'); 
            //$category = $request->input('category');
            if($request->input('category')){
                $category =  implode(",", $request->input('category'));
            }else{
                $category = "";
            }
            $content =  addslashes($request->input('content')); 
            $id =  $request->input('id'); 
            $site_link =  rtrim($request->input('site_link'),'/'); 
            $filename = '';
            if($request->input('tags')){
                $tags =  implode(",", $request->input('tags'));
            }else{
                $tags = "";
            }
            $display = $request->input('display_index');

            $web_server = $request->input('web_server');
            $theme = $request->input('theme');
            if($request->input('js_css_package')){
                $js_css_package = implode(",", $request->input('js_css_package'));
            }else{
                $js_css_package = "";
            }
            if($request->input('payment_method')){
                $payment_method = implode(",", $request->input('payment_method'));
            }else{
                $payment_method = "";
            }
            $multi_theme = $request->input('multi_theme');
            $multi_site = $request->input('multi_site');
            $duration = $request->input('duration');
            $addons = $request->input('addons');

            $this->validate($request,[
                'name' => 'required',
                'category' => 'required',
                'technology' => 'required',
                'display_index' => 'required',
                //'display_index' => 'unique:portfolio,display_index,'.$display,
                'content' => 'required',
                'site_link' => 'required',
            ]);

            if($request->file('image') != ''){

                $file = $request->file('image')->getClientOriginalName();
              
                $extension = explode(".", $file);
                $filename = date('ymdhis').".".$extension[1];
                $request->file('image')->move('template/frontend/images/', $filename);
                $filename = ',`image`  = "'.$filename.'"';
            } 

            
        if(isset($filename) && $filename!=""){
           $oldimage = $request->input('old_image');
           $file_path = base_path().'/template/frontend/images/'.$oldimage;
           unlink($file_path);
        }
            
           //echo 'UPDATE `portfolio` SET `title` = "'.$title.'", `category` ="'.$category.'", `technology` ="'.$technology.'", `tags` ="'.$tags.'", `content` = "'.$content.'", `site_link` = "'.$site_link.'" '.$filename.' , `display_index` ="'.$display.'", `web_server` ="'.$web_server.'", `theme` ="'.$theme.'", `js_css_packages` ="'.$js_css_package.'", `payment_methods` ="'.$payment_method.'", `multi_theme` ="'.$multi_theme.'", `multi_sites` ="'.$multi_site.'", `duration` = "'.$duration.'", `addons` ="'.$addons.'", `updated_at` = "'.$date.'" WHERE `portfolioid` = '.$id; die(); 
            //echo 'UPDATE `portfolio` SET `title` = "'.$title.'", `technology` ="'.$technology.'", `content` = "'.$content.'", `site_link` = "'.$site_link.'" '.$filename.' WHERE `portfolioid` = '.$id; exit;

            $query = DB::update('UPDATE `portfolio` SET `title` = "'.$title.'", `category` ="'.$category.'", `technology` ="'.$technology.'", `tags` ="'.$tags.'", `content` = "'.$content.'", `site_link` = "'.$site_link.'" '.$filename.' , `display_index` ="'.$display.'", `web_server` ="'.$web_server.'", `theme` ="'.$theme.'", `js_css_packages` ="'.$js_css_package.'", `payment_methods` ="'.$payment_method.'", `multi_theme` ="'.$multi_theme.'", `multi_sites` ="'.$multi_site.'", `duration` = "'.$duration.'", `addons` ="'.$addons.'", `updated_at` = "'.$date.'" WHERE `portfolioid` = '.$id);
           
           Session::flash('message', 'Portfolio updated successfully.');
           return redirect('admin/portfolio');
            
         
        } 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Portfolio  $portfolio
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    { 
        $query1 = DB::select('select * from portfolio where portfolioid = '.$id);
        foreach($query1 as $imagedata){
           $imagename = $imagedata->image;
           $file_path = base_path().'/template/frontend/images/'.$imagename;
           unlink($file_path);
           
        }
        
        $query = DB::table('portfolio')->where('portfolioid', '=', $id)->delete();


        Session::flash('message', 'Portfolio deleted successfully.');
        return redirect('admin/portfolio');
    }

    public function sortindex()
    {
        $data = array();
        $data['page'] = 'portfolioindex';
        $data['sortindex'] = DB::select('SELECT * FROM portfolio ORDER BY display_index ASC');
        return view('admin/portfolio/sortindex',$data);
    }
    public function sortupdate(Request $request)
    {
        $array = $request->input('arrayindex'); 
        $count = 1;
        foreach ($array as $idval) {
        
            $query = DB::update('UPDATE `portfolio` SET `display_index` ="'.$count.'" WHERE `portfolioid` = '.$idval);
            $count ++;
            
        }
        $data = array();
        $data['page'] = 'portfolioindex';
        $data['sortindex'] = DB::select('SELECT portfolioid,display_index,technology,title FROM portfolio ORDER BY display_index ASC');
        
        return response ()->json ( $data['sortindex'] );
        
    }
}
