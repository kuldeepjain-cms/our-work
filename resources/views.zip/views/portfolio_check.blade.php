@extends('app')

@section('content')
<style type="text/css">
	.welcome-portfolio { display: block; max-width: 600px; margin: 120px auto; padding: 30px; border: 1px solid #ccc; }
	.welcome-portfolio .container { max-width:100%;}
</style>
	<!--section class="main-container">
		<div class="container">
			<div class="row">
						<!-- main start -->
						<!-- ================ -->
						<!--div class="main col-md-12">

							<!-- page-title start -->
							<!-- ================ -->
							<!--h1 class="page-title">WelCome To CmsMinds</h1>
							<div class="separator-2"></div>

							<div class="image-boxes isotope-container row">

							<div class="col-sm-6 isotope-item web-design">
									<h4>Please Conatct us for watching our portfolio </h4>
									<br>
									mail us <a href="mailto:admin@cmsminds.com?Subject=Request%20For%20Portfolio" target="_top">admin@cmsminds.com</a>
								</div>


							</div>
						<!-- main end -->

					<!--div>
				</div>
			</section-->

			<div class="container portfolio">
                <div class="col-md-12 col-sm-12 col-xs-12 inner_container">
                 <div class="welcome-portfolio">
                    <h1 class="page-title">Welcome To cmsMinds</h1>
                            <div class="separator-2"></div>
		 
		                    <div class="container bootstrap snippet">
		                    
                        	<div class="projects-container scrollimation in">
                            <div class="row">
                           			<!--h4>Please Conatct us for watching our portfolio </h4>
									<br>
									mail us <a href="mailto:info@cmsminds.com?Subject=Request%20For%20Portfolio" target="_top">info@cmsminds.com</a-->	
									<p>The page you are looking for is not accessible without admin permission. So please contact us on <a href="mailto:info@cmsminds.com?Subject=Request%20For%20Portfolio" target="_top">info@cmsminds.com</a></p>
                            </div>
                        </div>
                    </div>
                   <div class="clearfix"></div>
                   </div>
                </div>
                 <div class="clearfix"></div>
        </div>

        <div class="clearfix"></div>
			<!--div class="section gray-bg text-muted footer-top clearfix">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="owl-carousel clients">
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-1.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-2.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-3.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-4.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-5.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-6.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-7.png') }}" alt=""></a>
								</div>
								<div class="client">
									<a href="#"><img src="{{ URL::asset('template/frontend/images/client-8.png') }}" alt=""></a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<blockquote class="inline">
								<p class="margin-clear">Design is not just what it looks like and feels like. Design is how it works.</p>
								<footer><cite title="Source Title">Steve Jobs </cite></footer>
							</blockquote>
						</div>
					</div>
				</div>
			</div-->
@endsection
