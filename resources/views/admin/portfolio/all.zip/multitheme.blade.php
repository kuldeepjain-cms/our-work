<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">            

            <!-- start: metrics table -->

            <div id="metrics-tables">
                
                <div class="table-responsive table-wrapper table-mobile">
                    <table class="table table-hover table-bordered fixed-head-table">
                        <thead>
                            <tr>
                                <th width="10%">Multi Theme Id</th>
                                <th width="10%">Multi Theme Name</th>
                            </tr>

                        </thead>
                        <tbody>
	                        
	                  
		            		<tr>
		            			<td>1</td>
		            			<td>Yes</td>
		            			
		            		</tr>
                            <tr>
                                <td>0</td>
                                <td>N0</td>
                                
                            </tr>

		            	
	                   
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- end: metrics table -->
            


        </div>
    </div>
</div>